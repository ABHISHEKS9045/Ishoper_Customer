package com.ishopper.mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
