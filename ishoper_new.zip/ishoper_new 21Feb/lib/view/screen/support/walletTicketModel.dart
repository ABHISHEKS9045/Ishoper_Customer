import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';

class WalletTicketProvider extends ChangeNotifier {



}